﻿using System;

namespace MT.OnlineRestaurant.UT
{
    public class Class1
    {
    }
}
